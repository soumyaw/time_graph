
AUTHOR: Christos Faloutsos
DATE: Feb. 2014

PURPOSE:
template for papers.
* Has \usepackage{paralist} for tight lists.
* has algorithm style
(* has tikz for drawings)

Also has \notice{}, to draw attention to important points
for presentation.
