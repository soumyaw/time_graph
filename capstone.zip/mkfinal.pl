#!/usr/bin/perl -w

use feature qw(say); # to automatically print a newline

# looks for \mkclean command
# and UNCOMMENTS comments it 
# thus creating a FINAL version

while(<>){
    # if( /% \mkclean/ ){ 
    # print "|", $_, "|\n";
    chomp;
    # print "|", $_, "|\n";
    if( /^% \\mkclean/ ){
        # print "got it\n";  
	# print "\\mkclean\n";
	say "\\mkclean";
	}
    else{
       # print;
       say;
    }
}
